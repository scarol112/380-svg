eid off
dim off
sxy off

color black
dir 90
r 10 8 A=0,0; lb "Physical page landscape length x width" A=6.6,0.25

r 9 7 A=0.5,0.5; lb "Page visible area (hardcoded 0.5in margins)" A=6.6,0.75
p 5px C=darkorange A=0.5,0.5
dir 135; l 0.075 0px A=0.5,0.5; l 0.1; l 0.05 0px; lb "Page origin"; dir 90

r 5 3 A=1.5,2; lb "Viewport" A=5.5,1.9
p 5px C=darkorange A=1.5,2
dir 135; l 0.075 0px A=1.5,2; l 0.1; l 0.05 0px; lb "VP origin"; dir 90

l 0 0px A=3,3
dir 90;l 2 dotted; dir 180; l 0.5 dotted; dir 270; l 2 dotted; dir 0; line 0.5 dotted; dir 90
include smfigure.dsl
dir 90
dir 45; l 0.075 0px A=3,3; l 0.1; l 0.05 0px; lb "Drawing origin"; dir 90

r 2 1 A=6.8,5; lb "Viewport" A=8.2,4.9
p 5px C=darkorange A=6.8,5
dir 45; l 0.075 0px A=6.8,5; l 0.1; l 0.05 0px; lb "VP origin"; dir 90

l 0 0px A=7,5.2
include smfigure.dsl
dir 90
dir 70; l 0.075 0px A=7,5.2; l 0.1; l 0.05 0px; lb "Drawing origin"; dir 90
dir 300; l 0.075 0px A=8.34,5.34; l 0.1; l 0.05 0px; lb "Elem origin"; dir 90

color black
l 0 0px A=0,0
lb "Print Space, Model Space, Origins, Dimensions" 24 A=2,-0.2

l 0 0px A=0,0
include border.dsl

#l 0 0px A=0,8; include rulerh10.dsl
#include grid10x8.dsl
