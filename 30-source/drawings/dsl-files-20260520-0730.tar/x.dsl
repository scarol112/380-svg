#tag testing

include border.dsl
paper= "letter","landscape"

pname, porient = paper


z=1,2
z0=z[0]

wall 20 0.25 A=1,1
dir 270; l 1" 0px
dir 180; wall 10 0.25
dir 45; l 1.80" 0px;
dir 270; wall 5 0.25
window 30" 3"
wall 2" 4"
window 30" 3"
wall 2" 4"
window 30" 3"
         wall  5 0.25

